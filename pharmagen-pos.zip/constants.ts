import { Drug, User, Sale } from './types';

export const INITIAL_DRUGS: Drug[] = [
  {
    id: '1',
    name: 'Panadol Extra',
    genericName: 'Paracetamol + Caffeine',
    description: 'Effective relief for headaches and muscle pain.',
    category: 'Pain Relief',
    price: 1500, // UGX Selling
    buyingPrice: 800, // UGX Buying
    minStockLevel: 50,
    requiresPrescription: false,
    unit: 'Tablets',
    batches: [
      { id: 'b1', expiryDate: '2025-12-01', quantity: 100 },
      { id: 'b2', expiryDate: '2024-06-01', quantity: 50 },
    ]
  },
  {
    id: '2',
    name: 'Amoxil 500mg',
    genericName: 'Amoxicillin',
    description: 'Antibiotic used to treat bacterial infections.',
    category: 'Antibiotics',
    price: 5000, // UGX Selling
    buyingPrice: 3000, // UGX Buying
    minStockLevel: 20,
    requiresPrescription: true,
    unit: 'Capsules',
    batches: [
      { id: 'b3', expiryDate: '2024-10-15', quantity: 40 },
    ]
  },
  {
    id: '3',
    name: 'Brufen 400mg',
    genericName: 'Ibuprofen',
    description: 'Anti-inflammatory drug for pain and fever.',
    category: 'Pain Relief',
    price: 3500, // UGX Selling
    buyingPrice: 2000, // UGX Buying
    minStockLevel: 30,
    requiresPrescription: false,
    unit: 'Tablets',
    batches: [
      { id: 'b4', expiryDate: '2026-01-20', quantity: 150 },
    ]
  },
  {
    id: '4',
    name: 'Cetrizine 10mg',
    genericName: 'Cetirizine Hydrochloride',
    description: 'Antihistamine for allergy relief.',
    category: 'Allergy',
    price: 1000, // UGX Selling
    buyingPrice: 400, // UGX Buying
    minStockLevel: 40,
    requiresPrescription: false,
    unit: 'Tablets',
    batches: [
      { id: 'b5', expiryDate: '2025-05-10', quantity: 80 },
    ]
  },
  {
    id: '5',
    name: 'Lipitor 20mg',
    genericName: 'Atorvastatin',
    description: 'Used to lower cholesterol levels.',
    category: 'Cardiovascular',
    price: 45000, // UGX Selling
    buyingPrice: 35000, // UGX Buying
    minStockLevel: 10,
    requiresPrescription: true,
    unit: 'Tablets',
    batches: [
      { id: 'b6', expiryDate: '2024-11-30', quantity: 25 },
    ]
  }
];

export const INITIAL_USERS: User[] = [
  { id: 'u1', name: 'System Admin', role: 'ADMIN', username: 'admin', password: 'password' },
  { id: 'u2', name: 'John Doe', role: 'PHARMACIST', username: 'staff', password: 'password' },
];

export const MOCK_SALES: Sale[] = [
  {
    id: 's1',
    timestamp: Date.now() - 86400000, // Yesterday
    totalAmount: 12500,
    paymentMethod: 'CASH',
    items: [
      { drugId: '1', drugName: 'Panadol Extra', quantity: 2, priceAtSale: 1500, buyingPriceAtSale: 800 }, 
      { drugId: '4', drugName: 'Cetrizine 10mg', quantity: 1, priceAtSale: 1000, buyingPriceAtSale: 400 }
    ]
  },
  {
    id: 's2',
    timestamp: Date.now() - 172800000, // 2 days ago
    totalAmount: 5000,
    paymentMethod: 'CARD',
    items: [
      { drugId: '2', drugName: 'Amoxil 500mg', quantity: 1, priceAtSale: 5000, buyingPriceAtSale: 3000 }
    ]
  }
];