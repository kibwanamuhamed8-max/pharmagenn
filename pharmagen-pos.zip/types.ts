
export enum ViewState {
  DASHBOARD = 'DASHBOARD',
  POS = 'POS',
  INVENTORY = 'INVENTORY',
  USERS = 'USERS',
  AI_ASSISTANT = 'AI_ASSISTANT',
  SALES_HISTORY = 'SALES_HISTORY'
}

export interface Batch {
  id: string;
  expiryDate: string;
  quantity: number;
}

export interface Drug {
  id: string;
  name: string;
  genericName: string;
  description: string;
  category: string;
  price: number; // Selling Price
  buyingPrice: number; // Cost Price
  batches: Batch[];
  minStockLevel: number;
  requiresPrescription: boolean;
  unit: string;
}

export interface CartItem extends Drug {
  cartQuantity: number;
  totalPrice: number;
}

export interface Sale {
  id: string;
  timestamp: number;
  items: {
    drugId: string;
    drugName: string;
    quantity: number;
    priceAtSale: number;
    buyingPriceAtSale?: number; // Optional for legacy data support
  }[];
  totalAmount: number;
  paymentMethod: 'CASH' | 'CARD' | 'MOBILE';
}

export interface User {
  id: string;
  name: string;
  role: 'ADMIN' | 'PHARMACIST';
  username: string;
  password?: string;
}

export interface DashboardStats {
  totalSales: number;
  totalOrders: number;
  lowStockCount: number;
  expiringSoonCount: number;
}