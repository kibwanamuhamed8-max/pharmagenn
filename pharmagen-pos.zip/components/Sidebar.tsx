
import React from 'react';
import { ViewState, User } from '../types';
import { LayoutDashboard, ShoppingCart, Package, Users, Bot, LogOut, Pill, Shield, TrendingUp } from 'lucide-react';

interface SidebarProps {
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
  currentUser: User;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, currentUser, onLogout }) => {
  
  const navItems = [
    { id: ViewState.DASHBOARD, label: 'Dashboard', icon: LayoutDashboard },
    { id: ViewState.POS, label: 'Point of Sale', icon: ShoppingCart },
    { id: ViewState.INVENTORY, label: 'Inventory', icon: Package },
    { id: ViewState.SALES_HISTORY, label: 'Sales History', icon: TrendingUp },
    { id: ViewState.AI_ASSISTANT, label: 'AI Assistant', icon: Bot },
  ];

  // Only add Users menu for Admins
  if (currentUser.role === 'ADMIN') {
    // Insert Users menu before AI Assistant (index 4 now because of Sales History)
    // Actually simpler to just filter/push. 
    // Let's just keep the order nice: Dashboard, POS, Inventory, History, Users, AI
    
    // Remove AI Assistant first to re-add at end
    const aiItem = navItems.pop();
    navItems.push({ id: ViewState.USERS, label: 'Staff & Access', icon: Users });
    if (aiItem) navItems.push(aiItem);
  }

  return (
    <div className="w-64 bg-secondary text-white h-screen flex flex-col shadow-xl z-10">
      <div className="p-6 flex items-center gap-3 border-b border-slate-800">
        <div className="bg-primary p-2 rounded-lg">
          <Pill size={24} className="text-white" />
        </div>
        <div>
          <h1 className="font-bold text-lg tracking-wide">PharmaGen</h1>
          <p className="text-xs text-slate-400">POS System v1.1</p>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                isActive 
                  ? 'bg-primary text-white shadow-lg shadow-primary/25 font-medium' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={20} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800 bg-slate-900/50">
        <div className="flex items-center gap-3 mb-4 px-2">
           <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
             currentUser.role === 'ADMIN' ? 'bg-indigo-500' : 'bg-emerald-500'
           }`}>
             {currentUser.name.charAt(0).toUpperCase()}
           </div>
           <div className="overflow-hidden">
             <p className="text-sm font-medium truncate">{currentUser.name}</p>
             <div className="flex items-center gap-1 text-[10px] text-slate-400 uppercase tracking-wider">
               {currentUser.role === 'ADMIN' && <Shield size={10} />}
               {currentUser.role}
             </div>
           </div>
        </div>
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-red-900/20 hover:text-red-400 transition-colors"
        >
          <LogOut size={20} />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};
