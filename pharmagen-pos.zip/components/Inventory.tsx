
import React, { useState } from 'react';
import { Drug, Batch } from '../types';
import { Plus, Edit2, Trash, AlertTriangle, Wand2, PackagePlus, Calendar, X } from 'lucide-react';
import { generateDrugDescription } from '../services/geminiService';

interface InventoryProps {
  drugs: Drug[];
  setDrugs: React.Dispatch<React.SetStateAction<Drug[]>>;
}

export const Inventory: React.FC<InventoryProps> = ({ drugs, setDrugs }) => {
  const [showModal, setShowModal] = useState(false);
  const [showRestockModal, setShowRestockModal] = useState(false);
  const [editingDrug, setEditingDrug] = useState<Drug | null>(null);
  const [restockDrug, setRestockDrug] = useState<Drug | null>(null);
  
  // Extended form data to include initial stock for new drugs
  const [formData, setFormData] = useState<Partial<Drug> & { initialQuantity?: number; initialExpiry?: string }>({
    name: '',
    genericName: '',
    category: '',
    price: 0,
    buyingPrice: 0,
    minStockLevel: 10,
    description: '',
    requiresPrescription: false,
    unit: '',
    initialQuantity: 0,
    initialExpiry: ''
  });

  const [restockData, setRestockData] = useState({ quantity: 0, expiryDate: '' });
  const [isGenerating, setIsGenerating] = useState(false);

  const unitOptions = [
    'Tablets',
    'Capsules',
    'Vials',
    'Ampoules',
    'Bottles',
    'Tubes',
    'Sachets',
    'Strips',
    'Packs',
    'Pieces',
    'Boxes',
    'Doses',
    'Milliliters (ml)',
    'Grams (g)'
  ];

  const handleEdit = (drug: Drug) => {
    setEditingDrug(drug);
    // Exclude batch data from form, but keep other fields
    setFormData({
        ...drug,
        initialQuantity: 0,
        initialExpiry: ''
    });
    setShowModal(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this drug?')) {
      setDrugs(prev => prev.filter(d => d.id !== id));
    }
  };

  const handleRestockClick = (drug: Drug) => {
    setRestockDrug(drug);
    setRestockData({ quantity: 0, expiryDate: '' });
    setShowRestockModal(true);
  };

  const handleGenerateDesc = async () => {
    if (!formData.name || !formData.genericName) {
        alert("Please enter Name and Generic Name first.");
        return;
    }
    setIsGenerating(true);
    const desc = await generateDrugDescription(formData.name, formData.genericName);
    setFormData(prev => ({ ...prev, description: desc }));
    setIsGenerating(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingDrug) {
        // Update existing drug
        // Extract specific fields to avoid overwriting batches with form helper fields
        const { initialQuantity, initialExpiry, ...drugFields } = formData;
        
        setDrugs(prev => prev.map(d => d.id === editingDrug.id ? { ...d, ...drugFields } as Drug : d));
    } else {
        // Create new drug
        const { initialQuantity, initialExpiry, ...drugFields } = formData;
        
        // Create initial batch if quantity is provided
        const batches: Batch[] = [];
        if (initialQuantity && initialQuantity > 0) {
            batches.push({
                id: `b-${Date.now()}`,
                quantity: initialQuantity,
                expiryDate: initialExpiry || new Date(Date.now() + 31536000000).toISOString().split('T')[0] // Default 1 year
            });
        }

        const newDrug: Drug = {
            ...drugFields as Drug,
            buyingPrice: drugFields.buyingPrice || 0,
            id: `drug-${Date.now()}`,
            batches: batches
        };
        setDrugs(prev => [...prev, newDrug]);
    }
    
    closeModal();
  };

  const handleRestockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!restockDrug || restockData.quantity <= 0) return;

    const newBatch: Batch = {
        id: `b-${Date.now()}`,
        quantity: restockData.quantity,
        expiryDate: restockData.expiryDate || new Date(Date.now() + 31536000000).toISOString().split('T')[0]
    };

    setDrugs(prev => prev.map(d => d.id === restockDrug.id ? { ...d, batches: [...d.batches, newBatch] } : d));
    
    setShowRestockModal(false);
    setRestockDrug(null);
    setRestockData({ quantity: 0, expiryDate: '' });
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingDrug(null);
    setFormData({
        name: '',
        genericName: '',
        category: '',
        price: 0,
        buyingPrice: 0,
        minStockLevel: 10,
        description: '',
        requiresPrescription: false,
        unit: '',
        initialQuantity: 0,
        initialExpiry: ''
    });
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Inventory Management</h2>
          <p className="text-slate-500">Manage drugs, prices, units, and stock levels.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-primary hover:bg-teal-700 text-white px-6 py-3 rounded-xl font-medium flex items-center gap-2 shadow-lg shadow-primary/30 transition-all"
        >
          <Plus size={20} />
          Add New Drug
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="p-4 font-semibold text-slate-600">Drug Name</th>
              <th className="p-4 font-semibold text-slate-600">Category</th>
              <th className="p-4 font-semibold text-slate-600">Unit Type</th>
              <th className="p-4 font-semibold text-slate-600">Buying (UGX)</th>
              <th className="p-4 font-semibold text-slate-600">Selling (UGX)</th>
              <th className="p-4 font-semibold text-slate-600">Total Stock</th>
              <th className="p-4 font-semibold text-slate-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {drugs.map(drug => {
              const totalStock = drug.batches.reduce((sum, b) => sum + b.quantity, 0);
              const isLowStock = totalStock <= drug.minStockLevel;
              
              return (
                <tr key={drug.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="p-4">
                    <div>
                      <div className="font-medium text-slate-800">{drug.name}</div>
                      <div className="text-xs text-slate-500">{drug.genericName}</div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-xs font-bold">
                      {drug.category}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-slate-600">
                    <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-medium border border-slate-200">
                      {drug.unit || 'N/A'}
                    </span>
                  </td>
                  <td className="p-4 font-medium text-slate-500 text-sm">{drug.buyingPrice ? drug.buyingPrice.toLocaleString() : '-'}</td>
                  <td className="p-4 font-medium text-slate-700">{drug.price.toLocaleString()}</td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${isLowStock ? 'text-red-600' : 'text-slate-700'}`}>
                        {totalStock}
                      </span>
                      {isLowStock && <AlertTriangle size={16} className="text-red-500" />}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                        {drug.batches.length} batch{drug.batches.length !== 1 ? 'es' : ''}
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex gap-2">
                       <button 
                        onClick={() => handleRestockClick(drug)} 
                        className="p-2 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors flex items-center gap-1"
                        title="Add Stock"
                      >
                        <PackagePlus size={16} />
                        <span className="text-xs font-bold">Add Stock</span>
                      </button>
                      <button onClick={() => handleEdit(drug)} className="p-2 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors" title="Edit Details">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => handleDelete(drug.id)} className="p-2 hover:bg-red-50 rounded-lg text-red-500 transition-colors" title="Delete">
                        <Trash size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Drug Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-[600px] max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-slate-800">{editingDrug ? 'Edit Drug Details' : 'Add New Drug'}</h3>
              <button onClick={closeModal} className="text-slate-400 hover:text-slate-600"><X size={24}/></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Drug Name</label>
                  <input required type="text" className="w-full p-2 border rounded-lg" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Panadol" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Generic Name</label>
                  <input required type="text" className="w-full p-2 border rounded-lg" value={formData.genericName} onChange={e => setFormData({...formData, genericName: e.target.value})} placeholder="e.g. Paracetamol" />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
                  <input required type="text" className="w-full p-2 border rounded-lg" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} placeholder="e.g. Pain Relief" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Unit Type</label>
                  <input 
                    list="unitOptions" 
                    required
                    className="w-full p-2 border rounded-lg bg-white"
                    value={formData.unit} 
                    onChange={e => setFormData({...formData, unit: e.target.value})}
                    placeholder="Select or type custom..."
                  />
                  <datalist id="unitOptions">
                    {unitOptions.map(option => (
                      <option key={option} value={option} />
                    ))}
                  </datalist>
                  <p className="text-[10px] text-slate-400 mt-1">Type to add a custom unit (e.g. "Blister")</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Buying Price</label>
                  <input required type="number" min="0" className="w-full p-2 border rounded-lg bg-slate-50" value={formData.buyingPrice} onChange={e => setFormData({...formData, buyingPrice: parseFloat(e.target.value)})} placeholder="Cost" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Selling Price</label>
                  <input required type="number" min="0" className="w-full p-2 border rounded-lg" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} placeholder="Sell" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Alert Level</label>
                  <input type="number" className="w-full p-2 border rounded-lg" value={formData.minStockLevel} onChange={e => setFormData({...formData, minStockLevel: parseInt(e.target.value)})} />
                </div>
              </div>

              {/* Initial Stock Section - Only for New Drugs */}
              {!editingDrug && (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                        <PackagePlus size={16} className="text-primary"/>
                        Initial Stock (First Batch)
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Initial Quantity</label>
                            <input 
                                type="number" 
                                min="0"
                                className="w-full p-2 border rounded-lg text-sm" 
                                value={formData.initialQuantity} 
                                onChange={e => setFormData({...formData, initialQuantity: parseInt(e.target.value)})}
                                placeholder="0"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">Expiry Date</label>
                            <input 
                                type="date" 
                                className="w-full p-2 border rounded-lg text-sm" 
                                value={formData.initialExpiry} 
                                onChange={e => setFormData({...formData, initialExpiry: e.target.value})}
                            />
                        </div>
                    </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Description (AI Auto-fill available)</label>
                <div className="relative">
                    <textarea 
                        className="w-full p-2 border rounded-lg h-24" 
                        value={formData.description} 
                        onChange={e => setFormData({...formData, description: e.target.value})} 
                    />
                    <button 
                        type="button"
                        onClick={handleGenerateDesc}
                        className="absolute bottom-2 right-2 bg-indigo-100 hover:bg-indigo-200 text-indigo-700 text-xs px-3 py-1 rounded-md flex items-center gap-1 transition-colors"
                    >
                        {isGenerating ? <span className="animate-spin">⌛</span> : <Wand2 size={12}/>}
                        {isGenerating ? 'Generating...' : 'Generate with AI'}
                    </button>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input type="checkbox" id="reqPresc" checked={formData.requiresPrescription} onChange={e => setFormData({...formData, requiresPrescription: e.target.checked})} className="w-5 h-5 accent-primary"/>
                <label htmlFor="reqPresc" className="text-slate-700 font-medium cursor-pointer">Requires Prescription</label>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={closeModal} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
                <button type="submit" className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-teal-700 shadow-lg shadow-primary/20">
                    {editingDrug ? 'Save Changes' : 'Create Drug'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Restock (Add Batch) Modal */}
      {showRestockModal && restockDrug && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-[400px] overflow-hidden animate-in fade-in zoom-in duration-200">
             <div className="bg-emerald-600 p-6 text-white">
                 <h3 className="text-xl font-bold">Add Stock</h3>
                 <p className="opacity-80 text-sm">Adding to: {restockDrug.name}</p>
             </div>
             
             <form onSubmit={handleRestockSubmit} className="p-6 space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Quantity to Add ({restockDrug.unit})</label>
                    <div className="relative">
                        <PackagePlus className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input 
                            autoFocus
                            required 
                            type="number" 
                            min="1"
                            className="w-full pl-10 p-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" 
                            value={restockData.quantity} 
                            onChange={e => setRestockData({...restockData, quantity: parseInt(e.target.value)})}
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Expiry Date</label>
                    <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input 
                            type="date" 
                            required
                            className="w-full pl-10 p-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" 
                            value={restockData.expiryDate} 
                            onChange={e => setRestockData({...restockData, expiryDate: e.target.value})}
                        />
                    </div>
                </div>

                <div className="pt-4 flex gap-3">
                    <button 
                        type="button" 
                        onClick={() => setShowRestockModal(false)}
                        className="flex-1 py-3 text-slate-600 font-bold hover:bg-slate-100 rounded-xl transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        type="submit"
                        className="flex-1 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-600/20 transition-colors"
                    >
                        Add Batch
                    </button>
                </div>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};