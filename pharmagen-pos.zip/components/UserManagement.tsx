import React, { useState } from 'react';
import { User } from '../types';
import { Plus, Trash, Shield, ShieldAlert, User as UserIcon, Lock } from 'lucide-react';

interface UserManagementProps {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  currentUser: User;
}

export const UserManagement: React.FC<UserManagementProps> = ({ users, setUsers, currentUser }) => {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    role: 'PHARMACIST' as 'ADMIN' | 'PHARMACIST',
    password: ''
  });

  const handleDelete = (id: string) => {
    if (id === currentUser.id) {
      alert("You cannot delete your own account.");
      return;
    }
    if (window.confirm('Are you sure you want to remove this user? This action cannot be undone.')) {
      setUsers(prev => prev.filter(u => u.id !== id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: User = {
      id: `u-${Date.now()}`,
      ...formData
    };
    setUsers(prev => [...prev, newUser]);
    setShowModal(false);
    setFormData({
      name: '',
      username: '',
      role: 'PHARMACIST',
      password: ''
    });
  };

  return (
    <div className="p-8 h-full overflow-y-auto bg-slate-50/50">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Staff Management</h2>
          <p className="text-slate-500">Manage user access and permissions.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-secondary hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-medium flex items-center gap-2 shadow-lg shadow-slate-900/10 transition-all"
        >
          <Plus size={20} />
          Add Staff Member
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map(user => (
          <div key={user.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between group hover:border-primary/30 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl font-bold ${
                  user.role === 'ADMIN' ? 'bg-indigo-100 text-indigo-600' : 'bg-emerald-100 text-emerald-600'
                }`}>
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">{user.name}</h3>
                  <p className="text-xs text-slate-500">@{user.username}</p>
                </div>
              </div>
              {user.role === 'ADMIN' ? (
                <Shield size={20} className="text-indigo-500" />
              ) : (
                <UserIcon size={20} className="text-emerald-500" />
              )}
            </div>

            <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-50">
              <span className={`px-3 py-1 rounded-lg text-xs font-bold tracking-wide uppercase ${
                user.role === 'ADMIN' ? 'bg-indigo-50 text-indigo-700' : 'bg-emerald-50 text-emerald-700'
              }`}>
                {user.role}
              </span>

              {user.id !== currentUser.id && (
                <button 
                  onClick={() => handleDelete(user.id)}
                  className="text-slate-400 hover:text-red-500 p-2 hover:bg-red-50 rounded-lg transition-colors"
                  title="Remove User"
                >
                  <Trash size={18} />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add User Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 bg-slate-50">
              <h3 className="text-xl font-bold text-slate-800">Add New Staff Member</h3>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    required 
                    type="text" 
                    className="w-full pl-10 p-3 border rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none" 
                    value={formData.name} 
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    placeholder="e.g. Jane Doe"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Username</label>
                <input 
                  required 
                  type="text" 
                  className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none" 
                  value={formData.username} 
                  onChange={e => setFormData({...formData, username: e.target.value})}
                  placeholder="e.g. janed"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Role</label>
                  <select 
                    className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-primary outline-none bg-white"
                    value={formData.role}
                    onChange={e => setFormData({...formData, role: e.target.value as any})}
                  >
                    <option value="PHARMACIST">Pharmacist</option>
                    <option value="ADMIN">Admin</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      required 
                      type="text" 
                      className="w-full pl-10 p-3 border rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none" 
                      value={formData.password} 
                      onChange={e => setFormData({...formData, password: e.target.value})}
                      placeholder="Access Code"
                    />
                  </div>
                </div>
              </div>

              {formData.role === 'ADMIN' && (
                <div className="flex gap-2 p-3 bg-amber-50 text-amber-800 text-xs rounded-lg border border-amber-100">
                  <ShieldAlert size={16} className="shrink-0 mt-0.5" />
                  <p>Admins have full access to system settings, user management, and sensitive data.</p>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-50 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowModal(false)} 
                  className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-6 py-2.5 bg-secondary text-white rounded-xl font-bold hover:bg-slate-800 transition-colors shadow-lg shadow-slate-900/10"
                >
                  Create Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};