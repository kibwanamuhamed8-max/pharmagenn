import React, { useState, useEffect } from 'react';
import { Drug, CartItem, Sale } from '../types';
import { Search, Trash2, CreditCard, CheckCircle, AlertCircle, Sparkles } from 'lucide-react';
import { checkDrugInteractions } from '../services/geminiService';

interface POSProps {
  drugs: Drug[];
  onProcessSale: (sale: Sale) => void;
}

export const POS: React.FC<POSProps> = ({ drugs, onProcessSale }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [interactionWarning, setInteractionWarning] = useState<string | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'CARD' | 'MOBILE'>('CASH');

  // Filter drugs based on search
  const filteredDrugs = drugs.filter(d => 
    d.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    d.genericName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToCart = (drug: Drug) => {
    // Simple logic: First batch that has stock
    const availableBatch = drug.batches.find(b => b.quantity > 0);
    
    if (!availableBatch) {
      alert("Out of stock!");
      return;
    }

    setCart(prev => {
      const existing = prev.find(item => item.id === drug.id);
      if (existing) {
        // Check if we have enough stock in total
        const totalStock = drug.batches.reduce((acc, b) => acc + b.quantity, 0);
        if (existing.cartQuantity + 1 > totalStock) {
          alert("Insufficient stock!");
          return prev;
        }
        return prev.map(item => item.id === drug.id ? { ...item, cartQuantity: item.cartQuantity + 1, totalPrice: (item.cartQuantity + 1) * item.price } : item);
      }
      return [...prev, { ...drug, cartQuantity: 1, totalPrice: drug.price, batchId: availableBatch.id }];
    });
    
    // Reset interaction warning when cart changes
    setInteractionWarning(null);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
    setInteractionWarning(null);
  };

  const updateQuantity = (id: string, change: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.cartQuantity + change);
        // Simplified check against total stock for demo
        const totalStock = item.batches.reduce((acc, b) => acc + b.quantity, 0);
        if (newQty > totalStock) return item;
        return { ...item, cartQuantity: newQty, totalPrice: newQty * item.price };
      }
      return item;
    }));
  };

  const calculateTotal = () => cart.reduce((acc, item) => acc + item.totalPrice, 0);

  const handleCheckInteractions = async () => {
    if (cart.length < 2) return;
    setIsChecking(true);
    const names = cart.map(c => c.name);
    const result = await checkDrugInteractions(names);
    setInteractionWarning(result);
    setIsChecking(false);
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;

    const newSale: Sale = {
      id: `sale-${Date.now()}`,
      timestamp: Date.now(),
      items: cart.map(c => ({
        drugId: c.id,
        drugName: c.name,
        quantity: c.cartQuantity,
        priceAtSale: c.price,
        buyingPriceAtSale: c.buyingPrice // Capture current cost
      })),
      totalAmount: calculateTotal(),
      paymentMethod
    };

    onProcessSale(newSale);
    setCart([]);
    setInteractionWarning(null);
    alert("Sale processed successfully!");
  };

  return (
    <div className="flex h-full bg-slate-100">
      {/* Left Side: Product Search */}
      <div className="flex-1 p-6 flex flex-col overflow-hidden">
        <div className="mb-6 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text"
            placeholder="Search drugs by name or generic..."
            className="w-full pl-12 pr-4 py-4 rounded-xl border-none shadow-sm focus:ring-2 focus:ring-primary outline-none text-lg"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 overflow-y-auto pb-20">
          {filteredDrugs.map(drug => {
            const totalStock = drug.batches.reduce((sum, b) => sum + b.quantity, 0);
            return (
              <div key={drug.id} 
                className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                onClick={() => addToCart(drug)}
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-slate-800 group-hover:text-primary transition-colors">{drug.name}</h3>
                    <span className="bg-slate-100 text-slate-600 text-xs font-bold px-2 py-1 rounded-lg">
                      UGX {drug.price.toLocaleString()} / {drug.unit || 'Unit'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mb-1">{drug.genericName}</p>
                  <p className="text-xs text-slate-400 line-clamp-2 mb-3">{drug.description}</p>
                </div>
                <div className="flex justify-between items-center text-xs font-medium mt-2">
                  <span className={totalStock < drug.minStockLevel ? 'text-red-500' : 'text-emerald-600'}>
                    {totalStock} {drug.unit || 'Units'} in stock
                  </span>
                  <span className="text-slate-400 bg-slate-50 px-2 py-1 rounded uppercase tracking-wider text-[10px]">
                    {drug.category}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Side: Cart */}
      <div className="w-96 bg-white shadow-2xl z-20 flex flex-col h-full border-l border-slate-200">
        <div className="p-6 border-b border-slate-100 bg-slate-50">
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <div className="w-2 h-8 bg-primary rounded-full"></div>
            Current Order
          </h2>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-60">
              <CreditCard size={48} className="mb-4" />
              <p>Cart is empty</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="flex-1">
                  <h4 className="font-medium text-slate-800">{item.name}</h4>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <span>{item.price.toLocaleString()} x</span>
                    <div className="flex items-center bg-white border border-slate-200 rounded-lg overflow-hidden">
                      <button className="px-2 py-1 hover:bg-slate-100" onClick={(e) => { e.stopPropagation(); updateQuantity(item.id, -1); }}>-</button>
                      <span className="px-2 font-bold">{item.cartQuantity}</span>
                      <button className="px-2 py-1 hover:bg-slate-100" onClick={(e) => { e.stopPropagation(); updateQuantity(item.id, 1); }}>+</button>
                    </div>
                    <span className="text-[10px] uppercase">{item.unit || 'Units'}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className="font-bold text-slate-800">{item.totalPrice.toLocaleString()}</span>
                  <button onClick={(e) => { e.stopPropagation(); removeFromCart(item.id); }} className="text-red-400 hover:text-red-600">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 1 && (
          <div className="px-6 pt-2">
            <button 
              onClick={handleCheckInteractions}
              disabled={isChecking}
              className="w-full py-2 bg-indigo-50 text-indigo-600 text-sm font-bold rounded-lg hover:bg-indigo-100 flex items-center justify-center gap-2 transition-colors"
            >
              <Sparkles size={16} />
              {isChecking ? 'Analyzing...' : 'Check Drug Interactions'}
            </button>
            
            {interactionWarning && (
               <div className="mt-3 p-3 bg-amber-50 border border-amber-100 rounded-lg text-xs text-amber-800">
                 <div className="flex items-center gap-1 mb-1 font-bold"><AlertCircle size={12}/> AI Analysis:</div>
                 <div className="whitespace-pre-line">{interactionWarning}</div>
               </div>
            )}
          </div>
        )}

        <div className="p-6 border-t border-slate-100 bg-slate-50">
          <div className="flex justify-between items-center mb-4">
            <span className="text-slate-500">Subtotal</span>
            <span className="text-xl font-bold text-slate-800">UGX {calculateTotal().toLocaleString()}</span>
          </div>
          
          <div className="grid grid-cols-3 gap-2 mb-4">
            {(['CASH', 'CARD', 'MOBILE'] as const).map(method => (
              <button 
                key={method}
                onClick={() => setPaymentMethod(method)}
                className={`py-2 text-xs font-bold rounded-lg border ${
                  paymentMethod === method 
                    ? 'bg-primary text-white border-primary' 
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {method}
              </button>
            ))}
          </div>

          <button 
            onClick={handleCheckout}
            disabled={cart.length === 0}
            className="w-full py-4 bg-secondary text-white font-bold rounded-xl hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-slate-900/20"
          >
            <CheckCircle size={20} />
            Complete Sale
          </button>
        </div>
      </div>
    </div>
  );
};