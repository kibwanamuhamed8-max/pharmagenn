import React, { useMemo } from 'react';
import { Drug, Sale } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { DollarSign, ShoppingBag, AlertTriangle, Activity } from 'lucide-react';

interface DashboardProps {
  drugs: Drug[];
  sales: Sale[];
}

export const Dashboard: React.FC<DashboardProps> = ({ drugs, sales }) => {

  const stats = useMemo(() => {
    const totalSales = sales.reduce((acc, sale) => acc + sale.totalAmount, 0);
    const lowStockCount = drugs.filter(d => {
        const totalStock = d.batches.reduce((sum, b) => sum + b.quantity, 0);
        return totalStock <= d.minStockLevel;
    }).length;
    const expiringSoonCount = drugs.filter(d => {
        return d.batches.some(b => {
            const expiry = new Date(b.expiryDate);
            const now = new Date();
            const diffTime = Math.abs(expiry.getTime() - now.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            return diffDays < 90; // 90 days warning
        });
    }).length;

    return {
      totalSales,
      totalOrders: sales.length,
      lowStockCount,
      expiringSoonCount
    };
  }, [drugs, sales]);

  // Mock Data for Charts (Sales over last 7 days)
  const salesData = [
    { name: 'Mon', sales: 450000 },
    { name: 'Tue', sales: 300000 },
    { name: 'Wed', sales: 250000 },
    { name: 'Thu', sales: 278000 },
    { name: 'Fri', sales: 189000 },
    { name: 'Sat', sales: 539000 },
    { name: 'Sun', sales: 349000 },
  ];

  // Category Distribution Mock
  const categoryData = [
    { name: 'Pain', count: 12 },
    { name: 'Antibiotics', count: 8 },
    { name: 'Allergy', count: 5 },
    { name: 'Cardio', count: 15 },
  ];

  return (
    <div className="p-8 h-full overflow-y-auto bg-slate-50/50">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Dashboard Overview</h2>
        <p className="text-slate-500">Welcome back. Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="p-4 bg-emerald-100 text-emerald-600 rounded-xl">
            <DollarSign size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Total Revenue</p>
            <h3 className="text-2xl font-bold text-slate-800">UGX {stats.totalSales.toLocaleString()}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="p-4 bg-blue-100 text-blue-600 rounded-xl">
            <ShoppingBag size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Total Orders</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.totalOrders}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="p-4 bg-amber-100 text-amber-600 rounded-xl">
            <AlertTriangle size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Low Stock Items</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.lowStockCount}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="p-4 bg-rose-100 text-rose-600 rounded-xl">
            <Activity size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Expiring Soon</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.expiringSoonCount}</h3>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 lg:col-span-2">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Weekly Sales Analytics (UGX)</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} tickFormatter={(val) => `${(val/1000).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{backgroundColor: '#fff', borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                  formatter={(val: number) => [`UGX ${val.toLocaleString()}`, 'Sales']}
                />
                <Line 
                  type="monotone" 
                  dataKey="sales" 
                  stroke="#0d9488" 
                  strokeWidth={3} 
                  dot={{fill: '#0d9488', strokeWidth: 2, r: 4, stroke: '#fff'}}
                  activeDot={{r: 6, strokeWidth: 0}}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Inventory by Category</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} layout="vertical" margin={{top: 0, right: 0, bottom: 0, left: 30}}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                <Tooltip cursor={{fill: '#f1f5f9'}} contentStyle={{borderRadius: '8px'}} />
                <Bar dataKey="count" fill="#38bdf8" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};