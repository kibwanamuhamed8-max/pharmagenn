
import React, { useState, useMemo } from 'react';
import { Sale } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar, DollarSign, Package, TrendingUp, Clock, FileText, Edit2, Save, X, Trash2, ArrowRight, AlertCircle, Download, Printer, FileSpreadsheet } from 'lucide-react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

interface SalesHistoryProps {
  sales: Sale[];
  onUpdateSale: (updatedSale: Sale) => void;
}

type Timeframe = 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'YEARLY';

export const SalesHistory: React.FC<SalesHistoryProps> = ({ sales, onUpdateSale }) => {
  const [timeframe, setTimeframe] = useState<Timeframe>('WEEKLY');
  const [activeTab, setActiveTab] = useState<'TRANSACTIONS' | 'DISPENSED'>('DISPENSED');
  
  // Edit State
  const [editingSale, setEditingSale] = useState<Sale | null>(null);
  
  // Drill Down State
  const [drillDownDrug, setDrillDownDrug] = useState<{id: string, name: string} | null>(null);

  // Filter Sales based on Timeframe
  const filteredSales = useMemo(() => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    
    // Helper to get start of week (Monday)
    const getStartOfWeek = (d: Date) => {
      const day = d.getDay(), diff = d.getDate() - day + (day === 0 ? -6 : 1);
      return new Date(d.setDate(diff)).setHours(0,0,0,0);
    };

    const startOfWeek = getStartOfWeek(new Date());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    const startOfYear = new Date(now.getFullYear(), 0, 1).getTime();

    return sales.filter(sale => {
      if (timeframe === 'DAILY') return sale.timestamp >= startOfDay;
      if (timeframe === 'WEEKLY') return sale.timestamp >= startOfWeek;
      if (timeframe === 'MONTHLY') return sale.timestamp >= startOfMonth;
      if (timeframe === 'YEARLY') return sale.timestamp >= startOfYear;
      return true;
    });
  }, [sales, timeframe]);

  // Aggregate Stats including PROFIT
  const stats = useMemo(() => {
    const totalRevenue = filteredSales.reduce((sum, s) => sum + s.totalAmount, 0);
    const totalTransactions = filteredSales.length;
    const totalItemsDispensed = filteredSales.reduce((sum, s) => sum + s.items.reduce((iSum, i) => iSum + i.quantity, 0), 0);
    
    // Calculate Profit
    const grossProfit = filteredSales.reduce((acc, sale) => {
        const saleProfit = sale.items.reduce((itemAcc, item) => {
            // If buyingPriceAtSale is missing (legacy data), default to 0 or try to handle gracefully
            // For this demo, we treat cost as 0 if missing, implying full profit, but ideally we'd check current drug list
            const cost = item.buyingPriceAtSale || 0;
            return itemAcc + ((item.priceAtSale - cost) * item.quantity);
        }, 0);
        return acc + saleProfit;
    }, 0);

    return { totalRevenue, totalTransactions, totalItemsDispensed, grossProfit };
  }, [filteredSales]);

  // Prepare Chart Data
  const chartData = useMemo(() => {
    const data: Record<string, { sales: number, profit: number }> = {};
    
    filteredSales.forEach(sale => {
      const date = new Date(sale.timestamp);
      let key = '';
      
      if (timeframe === 'DAILY') {
        key = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      } else if (timeframe === 'WEEKLY') {
        key = date.toLocaleDateString([], { weekday: 'short' });
      } else if (timeframe === 'MONTHLY') {
        key = date.toLocaleDateString([], { day: 'numeric', month: 'short' });
      } else {
        key = date.toLocaleDateString([], { month: 'long' });
      }

      const saleProfit = sale.items.reduce((acc, item) => acc + ((item.priceAtSale - (item.buyingPriceAtSale || 0)) * item.quantity), 0);

      if (!data[key]) data[key] = { sales: 0, profit: 0 };
      data[key].sales += sale.totalAmount;
      data[key].profit += saleProfit;
    });

    return Object.entries(data).map(([name, val]) => ({ name, sales: val.sales, profit: val.profit }));
  }, [filteredSales, timeframe]);

  // Dispensing History Aggregation
  const dispensedItems = useMemo(() => {
    const items: Record<string, { drugId: string, name: string, quantity: number, revenue: number }> = {};
    
    filteredSales.forEach(sale => {
      sale.items.forEach(item => {
        if (!items[item.drugId]) {
          items[item.drugId] = { drugId: item.drugId, name: item.drugName, quantity: 0, revenue: 0 };
        }
        items[item.drugId].quantity += item.quantity;
        items[item.drugId].revenue += (item.quantity * item.priceAtSale);
      });
    });

    return Object.values(items).sort((a, b) => b.quantity - a.quantity);
  }, [filteredSales]);

  // EXPORT FUNCTIONS
  const exportToCSV = () => {
    const headers = ['Sale ID', 'Date', 'Items', 'Method', 'Total Amount', 'Profit'];
    const rows = filteredSales.map(sale => {
        const profit = sale.items.reduce((acc, i) => acc + ((i.priceAtSale - (i.buyingPriceAtSale || 0)) * i.quantity), 0);
        const itemsStr = sale.items.map(i => `${i.quantity}x ${i.drugName}`).join('; ');
        return [
            sale.id,
            new Date(sale.timestamp).toLocaleString(),
            `"${itemsStr}"`, // Quote to handle commas in descriptions
            sale.paymentMethod,
            sale.totalAmount,
            profit
        ];
    });

    const csvContent = "data:text/csv;charset=utf-8," 
        + headers.join(",") + "\n" 
        + rows.map(e => e.join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `sales_report_${timeframe.toLowerCase()}_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text(`Sales Report - ${timeframe} View`, 14, 15);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 22);
    
    // Stats Summary
    doc.setFontSize(10);
    doc.text(`Total Revenue: UGX ${stats.totalRevenue.toLocaleString()}`, 14, 30);
    doc.text(`Gross Profit: UGX ${stats.grossProfit.toLocaleString()}`, 14, 36);
    doc.text(`Transactions: ${stats.totalTransactions}`, 80, 30);
    doc.text(`Items Dispensed: ${stats.totalItemsDispensed}`, 80, 36);

    // Table
    const tableColumn = ["Date", "Sale ID", "Items", "Amount (UGX)", "Profit (UGX)"];
    const tableRows: any[] = [];

    filteredSales.forEach(sale => {
        const profit = sale.items.reduce((acc, i) => acc + ((i.priceAtSale - (i.buyingPriceAtSale || 0)) * i.quantity), 0);
        const saleData = [
            new Date(sale.timestamp).toLocaleDateString(),
            sale.id.split('-')[1] || sale.id,
            sale.items.map(i => `${i.quantity}x ${i.drugName}`).join(', '),
            sale.totalAmount.toLocaleString(),
            profit.toLocaleString()
        ];
        tableRows.push(saleData);
    });

    (doc as any).autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 45,
        styles: { fontSize: 8 },
        headStyles: { fillColor: [13, 148, 136] } // primary color
    });

    doc.save(`sales_report_${timeframe.toLowerCase()}.pdf`);
  };

  // Handle Edit Logic
  const handleEditClick = (sale: Sale) => {
    setEditingSale(JSON.parse(JSON.stringify(sale)));
  };

  const handleDrillDown = (drugId: string, drugName: string) => {
    const relevantSales = filteredSales.filter(s => s.items.some(i => i.drugId === drugId));
    if (relevantSales.length === 0) return;
    if (relevantSales.length === 1) {
      handleEditClick(relevantSales[0]);
    } else {
      setDrillDownDrug({ id: drugId, name: drugName });
    }
  };

  const updateEditingItem = (index: number, field: 'quantity' | 'priceAtSale', value: number) => {
    if (!editingSale) return;
    const newItems = [...editingSale.items];
    newItems[index] = { ...newItems[index], [field]: value };
    const newTotal = newItems.reduce((acc, item) => acc + (item.quantity * item.priceAtSale), 0);
    setEditingSale({ ...editingSale, items: newItems, totalAmount: newTotal });
  };

  const removeEditingItem = (index: number) => {
    if (!editingSale) return;
    const newItems = editingSale.items.filter((_, i) => i !== index);
    const newTotal = newItems.reduce((acc, item) => acc + (item.quantity * item.priceAtSale), 0);
    setEditingSale({ ...editingSale, items: newItems, totalAmount: newTotal });
  };

  const saveChanges = () => {
    if (!editingSale) return;
    if (editingSale.items.length === 0) {
        if (!confirm("Removing all items will effectively delete this sale record. Continue?")) return;
    }
    onUpdateSale(editingSale);
    setEditingSale(null);
  };

  return (
    <div className="p-8 h-full overflow-y-auto bg-slate-50/50">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Sales & Profit Analytics</h2>
          <p className="text-slate-500">Track revenue, calculate profits, and export reports.</p>
        </div>
        
        <div className="flex gap-3">
             <div className="bg-white p-1 rounded-xl border border-slate-200 shadow-sm flex">
              {(['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setTimeframe(t)}
                  className={`px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                    timeframe === t 
                      ? 'bg-secondary text-white shadow-md' 
                      : 'text-slate-500 hover:bg-slate-50'
                  }`}
                >
                  {t.charAt(0) + t.slice(1).toLowerCase()}
                </button>
              ))}
            </div>

            <div className="flex bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <button onClick={exportToCSV} className="p-3 hover:bg-slate-50 text-slate-600 border-r border-slate-100" title="Export CSV (Excel)">
                    <FileSpreadsheet size={18} />
                </button>
                <button onClick={exportToPDF} className="p-3 hover:bg-slate-50 text-slate-600" title="Export PDF">
                    <Download size={18} />
                </button>
            </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="p-4 bg-emerald-100 text-emerald-600 rounded-xl">
            <DollarSign size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Revenue</p>
            <h3 className="text-xl font-bold text-slate-800">UGX {stats.totalRevenue.toLocaleString()}</h3>
          </div>
        </div>

        {/* Profit Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4 relative overflow-hidden">
           <div className="absolute top-0 right-0 p-2 bg-teal-500 text-white text-[10px] font-bold rounded-bl-xl">NET</div>
          <div className="p-4 bg-teal-100 text-teal-600 rounded-xl">
            <TrendingUp size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Gross Profit</p>
            <h3 className="text-xl font-bold text-teal-700">UGX {stats.grossProfit.toLocaleString()}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="p-4 bg-blue-100 text-blue-600 rounded-xl">
            <Package size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Dispensed</p>
            <h3 className="text-xl font-bold text-slate-800">{stats.totalItemsDispensed}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="p-4 bg-indigo-100 text-indigo-600 rounded-xl">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Transacts</p>
            <h3 className="text-xl font-bold text-slate-800">{stats.totalTransactions}</h3>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 mb-8">
        <h3 className="text-lg font-bold text-slate-800 mb-6">Financial Performance ({timeframe.toLowerCase()})</h3>
        <div className="h-[300px]">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} tickFormatter={(val) => `UGX ${(val/1000).toFixed(0)}k`} />
                <Tooltip 
                  cursor={{fill: '#f1f5f9'}}
                  contentStyle={{backgroundColor: '#fff', borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                  formatter={(val: number, name: string) => [`UGX ${val.toLocaleString()}`, name === 'sales' ? 'Revenue' : 'Profit']}
                />
                <Bar dataKey="sales" name="Sales" fill="#94a3b8" radius={[4, 4, 0, 0]} barSize={30} />
                <Bar dataKey="profit" name="Profit" fill="#0d9488" radius={[4, 4, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-400">
              No sales data for this period
            </div>
          )}
        </div>
      </div>

      {/* Detailed Views */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-100">
          <button 
            onClick={() => setActiveTab('DISPENSED')}
            className={`px-6 py-4 font-bold text-sm flex items-center gap-2 transition-colors ${
              activeTab === 'DISPENSED' ? 'text-primary border-b-2 border-primary bg-slate-50' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Package size={18} />
            Dispensed Items
          </button>
          <button 
            onClick={() => setActiveTab('TRANSACTIONS')}
            className={`px-6 py-4 font-bold text-sm flex items-center gap-2 transition-colors ${
              activeTab === 'TRANSACTIONS' ? 'text-primary border-b-2 border-primary bg-slate-50' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <FileText size={18} />
            Transaction Log
          </button>
        </div>

        <div className="p-0">
          {activeTab === 'DISPENSED' ? (
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Drug Name</th>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Total Quantity</th>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Total Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dispensedItems.length > 0 ? (
                  dispensedItems.map((item) => (
                    <tr 
                      key={item.drugId} 
                      className="hover:bg-slate-50 transition-colors cursor-pointer group"
                      onDoubleClick={() => handleDrillDown(item.drugId, item.name)}
                      title="Double click to edit transactions for this drug"
                    >
                      <td className="p-4 text-sm font-medium text-slate-800 flex items-center gap-2">
                        {item.name}
                        <span className="opacity-0 group-hover:opacity-100 text-xs text-primary bg-primary/10 px-1.5 py-0.5 rounded flex items-center gap-1">
                          <Edit2 size={10} /> Edit
                        </span>
                      </td>
                      <td className="p-4 text-sm text-slate-600">{item.quantity} units</td>
                      <td className="p-4 text-sm font-bold text-slate-700">UGX {item.revenue.toLocaleString()}</td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={3} className="p-8 text-center text-slate-400">No items dispensed in this period</td></tr>
                )}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Time</th>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Sale ID</th>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Items</th>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Amount</th>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Est. Profit</th>
                  <th className="p-4 font-semibold text-slate-600 text-sm">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSales.length > 0 ? (
                  filteredSales.sort((a,b) => b.timestamp - a.timestamp).map((sale) => {
                    const profit = sale.items.reduce((acc, i) => acc + ((i.priceAtSale - (i.buyingPriceAtSale || 0)) * i.quantity), 0);
                    return (
                    <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-4 text-sm text-slate-600 flex items-center gap-2">
                        <Clock size={14} />
                        {new Date(sale.timestamp).toLocaleString()}
                      </td>
                      <td className="p-4 text-sm font-mono text-slate-500">{sale.id.split('-')[1] || sale.id}</td>
                      <td className="p-4 text-sm text-slate-600">
                        {sale.items.map(i => `${i.quantity}x ${i.drugName}`).join(', ')}
                      </td>
                      <td className="p-4 text-sm font-bold text-slate-700">UGX {sale.totalAmount.toLocaleString()}</td>
                      <td className="p-4 text-sm font-bold text-emerald-600">UGX {profit.toLocaleString()}</td>
                      <td className="p-4">
                        <button 
                          onClick={() => handleEditClick(sale)}
                          className="p-2 text-slate-400 hover:text-primary hover:bg-slate-100 rounded-lg transition-colors"
                          title="Edit Prescription"
                        >
                          <Edit2 size={16} />
                        </button>
                      </td>
                    </tr>
                    );
                  })
                ) : (
                  <tr><td colSpan={6} className="p-8 text-center text-slate-400">No transactions in this period</td></tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Drill Down Modal (Multiple Sales) */}
      {drillDownDrug && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
             <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-slate-800">Sales containing "{drillDownDrug.name}"</h3>
                <p className="text-xs text-slate-500">Found multiple transactions. Select one to edit.</p>
              </div>
              <button onClick={() => setDrillDownDrug(null)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            <div className="max-h-[60vh] overflow-y-auto">
              {filteredSales
                .filter(s => s.items.some(i => i.drugId === drillDownDrug.id))
                .sort((a,b) => b.timestamp - a.timestamp)
                .map(sale => {
                  const drugItem = sale.items.find(i => i.drugId === drillDownDrug.id);
                  return (
                    <div key={sale.id} className="p-4 border-b border-slate-100 hover:bg-slate-50 transition-colors flex items-center justify-between">
                       <div>
                          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                             <Clock size={12} /> {new Date(sale.timestamp).toLocaleString()}
                          </div>
                          <div className="font-medium text-slate-800">
                             Sold <span className="font-bold">{drugItem?.quantity}</span> units
                          </div>
                          <div className="text-xs text-slate-400 font-mono mt-0.5">ID: {sale.id}</div>
                       </div>
                       <button 
                         onClick={() => {
                           setDrillDownDrug(null);
                           handleEditClick(sale);
                         }}
                         className="px-3 py-1.5 bg-white border border-slate-200 text-slate-600 text-sm font-medium rounded-lg hover:border-primary hover:text-primary transition-colors flex items-center gap-1"
                       >
                         Edit <ArrowRight size={14} />
                       </button>
                    </div>
                  );
                })}
            </div>
            <div className="p-4 bg-slate-50 text-center text-xs text-slate-400 border-t border-slate-100">
               Select a transaction above to modify quantities or prices.
            </div>
          </div>
        </div>
      )}

      {/* Edit Sale Modal */}
      {editingSale && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-slate-800">Edit Dispensed Prescription</h3>
                <p className="text-xs text-slate-500 font-mono">ID: {editingSale.id}</p>
              </div>
              <button onClick={() => setEditingSale(null)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6 max-h-[60vh] overflow-y-auto">
              <table className="w-full text-left mb-6">
                <thead className="text-xs text-slate-500 uppercase bg-slate-50">
                  <tr>
                    <th className="p-3 rounded-l-lg">Drug</th>
                    <th className="p-3 w-24">Qty</th>
                    <th className="p-3 w-32">Price (UGX)</th>
                    <th className="p-3 w-24">Total</th>
                    <th className="p-3 rounded-r-lg w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {editingSale.items.map((item, idx) => (
                    <tr key={idx}>
                      <td className="p-3 font-medium text-slate-700">{item.drugName}</td>
                      <td className="p-3">
                        <input 
                          type="number" 
                          min="1"
                          className="w-full p-2 border rounded-lg text-sm"
                          value={item.quantity}
                          onChange={(e) => updateEditingItem(idx, 'quantity', parseInt(e.target.value) || 0)}
                        />
                      </td>
                      <td className="p-3">
                        <input 
                          type="number" 
                          min="0"
                          className="w-full p-2 border rounded-lg text-sm"
                          value={item.priceAtSale}
                          onChange={(e) => updateEditingItem(idx, 'priceAtSale', parseFloat(e.target.value) || 0)}
                        />
                      </td>
                      <td className="p-3 text-sm font-bold text-slate-600">
                        {(item.quantity * item.priceAtSale).toLocaleString()}
                      </td>
                      <td className="p-3">
                        <button 
                          onClick={() => removeEditingItem(idx)}
                          className="text-red-400 hover:text-red-600 p-1 hover:bg-red-50 rounded"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="flex justify-end items-center gap-4 p-4 bg-slate-50 rounded-xl">
                 <span className="text-slate-500 font-medium">New Total:</span>
                 <span className="text-2xl font-bold text-slate-800">UGX {editingSale.totalAmount.toLocaleString()}</span>
              </div>
              
              <div className="mt-4 p-3 bg-blue-50 text-blue-800 text-xs rounded-lg flex gap-2">
                 <div className="shrink-0 mt-0.5 font-bold"><AlertCircle size={14}/></div>
                 <p>Modifying quantities will automatically update the inventory stock levels. Reducing quantity adds stock back; increasing quantity deducts stock.</p>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button 
                onClick={() => setEditingSale(null)} 
                className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-medium transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={saveChanges}
                className="px-6 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-teal-700 transition-colors flex items-center gap-2 shadow-lg shadow-primary/20"
              >
                <Save size={18} />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
