import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates a description for a drug based on its name and generic name.
 */
export const generateDrugDescription = async (name: string, genericName: string): Promise<string> => {
  try {
    const prompt = `Write a concise, 1-sentence medical description for the drug "${name}" (Generic: ${genericName}). Focus on its primary use case.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "No description available.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Failed to generate description.";
  }
};

/**
 * Checks for potential drug interactions between a list of drugs.
 */
export const checkDrugInteractions = async (drugNames: string[]): Promise<string> => {
  try {
    if (drugNames.length < 2) {
      return "Please select at least two drugs to check for interactions.";
    }

    const prompt = `Analyze the following list of drugs for potential adverse interactions: ${drugNames.join(', ')}. 
    Provide a brief summary. If there are no major interactions, state that clearly. Format as a short bulleted list.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "No interaction data available.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to check interactions at this time.";
  }
};

/**
 * General medical assistant chat.
 */
export const askMedicalAssistant = async (query: string): Promise<string> => {
  try {
    const prompt = `You are a helpful AI assistant for a pharmacist. Answer the following question concisely and professionally: "${query}"`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "I couldn't understand the query.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Assistant is currently unavailable.";
  }
};