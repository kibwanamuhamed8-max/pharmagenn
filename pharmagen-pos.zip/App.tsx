
import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { POS } from './components/POS';
import { Inventory } from './components/Inventory';
import { AIAssistant } from './components/AIAssistant';
import { UserManagement } from './components/UserManagement';
import { SalesHistory } from './components/SalesHistory';
import { Login } from './components/Login';
import { Drug, Sale, ViewState, User } from './types';
import { INITIAL_DRUGS, MOCK_SALES, INITIAL_USERS } from './constants';

// Main App Component
const App: React.FC = () => {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  // Application Data State
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.DASHBOARD);
  const [drugs, setDrugs] = useState<Drug[]>(INITIAL_DRUGS);
  const [sales, setSales] = useState<Sale[]>(MOCK_SALES);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);

  // Authentication Handlers
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setCurrentView(ViewState.DASHBOARD);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  // Process Sale Handler
  const handleProcessSale = (newSale: Sale) => {
    // 1. Add to sales history
    setSales(prev => [newSale, ...prev]);

    // 2. Deduct stock from drugs
    setDrugs(prevDrugs => prevDrugs.map(drug => {
      const saleItem = newSale.items.find(item => item.drugId === drug.id);
      if (saleItem) {
        let remainingQtyToDeduct = saleItem.quantity;
        // Simple logic: deduct from first available batch
        // In a real app, this should follow FIFO or specific batch selection
        const updatedBatches = drug.batches.map(batch => {
            if (remainingQtyToDeduct <= 0) return batch;
            if (batch.quantity >= remainingQtyToDeduct) {
                const updated = { ...batch, quantity: batch.quantity - remainingQtyToDeduct };
                remainingQtyToDeduct = 0;
                return updated;
            } else {
                remainingQtyToDeduct -= batch.quantity;
                return { ...batch, quantity: 0 };
            }
        });
        return { ...drug, batches: updatedBatches };
      }
      return drug;
    }));
  };

  // Update Sale Handler (Edit after dispensing)
  const handleUpdateSale = (updatedSale: Sale) => {
    const oldSale = sales.find(s => s.id === updatedSale.id);
    if (!oldSale) return;

    // 1. Revert stock for items in the OLD sale
    // We add the quantity back to the first available batch (simplified logic)
    const drugsAfterRevert = drugs.map(drug => {
      const oldItem = oldSale.items.find(i => i.drugId === drug.id);
      if (oldItem) {
        // Add back to first batch found
        const batches = [...drug.batches];
        if (batches.length > 0) {
           batches[0] = { ...batches[0], quantity: batches[0].quantity + oldItem.quantity };
        } else {
           // If no batches exist, create a generic one? Or just ignore for now as this is edge case
        }
        return { ...drug, batches };
      }
      return drug;
    });

    // 2. Apply stock deduction for items in the NEW (updated) sale
    const finalDrugs = drugsAfterRevert.map(drug => {
       const newItem = updatedSale.items.find(i => i.drugId === drug.id);
       if (newItem) {
         let remaining = newItem.quantity;
         const batches = drug.batches.map(b => {
             if (remaining <= 0) return b;
             if (b.quantity >= remaining) {
                 const updated = { ...b, quantity: b.quantity - remaining };
                 remaining = 0;
                 return updated;
             } else {
                 remaining -= b.quantity;
                 return { ...b, quantity: 0 };
             }
         });
         return { ...drug, batches };
       }
       return drug;
    });

    setDrugs(finalDrugs);
    setSales(prev => prev.map(s => s.id === updatedSale.id ? updatedSale : s));
  };

  // Render Login if not authenticated
  if (!currentUser) {
    return <Login users={users} onLogin={handleLogin} />;
  }

  // Render Content based on ViewState
  const renderContent = () => {
    switch (currentView) {
      case ViewState.DASHBOARD:
        return <Dashboard drugs={drugs} sales={sales} />;
      case ViewState.POS:
        return <POS drugs={drugs} onProcessSale={handleProcessSale} />;
      case ViewState.INVENTORY:
        return <Inventory drugs={drugs} setDrugs={setDrugs} />;
      case ViewState.SALES_HISTORY:
        return <SalesHistory sales={sales} onUpdateSale={handleUpdateSale} />;
      case ViewState.AI_ASSISTANT:
        return <AIAssistant />;
      case ViewState.USERS:
        // Double check permissions
        if (currentUser.role !== 'ADMIN') return <Dashboard drugs={drugs} sales={sales} />;
        return <UserManagement users={users} setUsers={setUsers} currentUser={currentUser} />;
      default:
        return <Dashboard drugs={drugs} sales={sales} />;
    }
  };

  return (
    <div className="flex h-screen w-screen bg-slate-50">
      <Sidebar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        currentUser={currentUser}
        onLogout={handleLogout}
      />
      <main className="flex-1 h-full overflow-hidden relative">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;
